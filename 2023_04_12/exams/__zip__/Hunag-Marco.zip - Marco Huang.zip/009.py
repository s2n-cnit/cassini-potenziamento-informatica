def mia_len(elemento):
    lunghezza = 0
    for _ in elemento:
        lunghezza += 1
    return lunghezza

mia_len()