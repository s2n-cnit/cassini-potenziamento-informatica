# Definisci la lista di numeri
lista_numeri = [10, 20, 30, 40, 50]

# Inizializza una variabile per la somma
somma = 0

# Utilizza un ciclo for per iterare su ciascun elemento della lista
for numero in lista_numeri:
    # Aggiungi il numero corrente alla somma
    somma += numero

# Stampa la somma a schermo
print("La somma di tutti gli elementi nella lista è:", somma)