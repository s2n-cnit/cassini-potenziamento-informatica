def pr():
    yay = True
    while yay:
        i = input()
        if i != '':
            print(i)
        else:
            yay = False
            
pr()