import csv

def writeusers()