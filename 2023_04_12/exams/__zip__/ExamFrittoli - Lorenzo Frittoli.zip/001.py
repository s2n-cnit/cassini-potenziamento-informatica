def max_2():
    a = float(input('1st number: '))
    b = float(input('2nd number: '))
    
    if a > b:
        print(a)
    else:
        print(b)
        
max_2()