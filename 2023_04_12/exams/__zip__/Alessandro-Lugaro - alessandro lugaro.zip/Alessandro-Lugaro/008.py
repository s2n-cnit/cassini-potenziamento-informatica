def crea_istogramma(lista_numeri):
    for numero in lista_numeri:
        print('*' * numero)