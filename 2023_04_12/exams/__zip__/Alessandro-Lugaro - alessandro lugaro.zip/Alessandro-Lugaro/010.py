def lunghezza_parole(lista_parole):
    lista_lunghezze = [len(parola) for parola in lista_parole]
    return lista_lunghezze

