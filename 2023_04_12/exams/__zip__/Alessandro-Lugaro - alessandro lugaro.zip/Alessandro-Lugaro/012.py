def converti_unita_di_misura(metri):
    pollice = metri / 0.0254
    piede = metri / 0.3048
    iarda = metri / 0.9144
    miglia = metri / 1609.344

    print("Equivalente in pollici:", pollice)
    print("Equivalente in piedi:", piede)
    print("Equivalente in iarde:", iarda)
    print("Equivalente in miglia terrestri:", miglia)
