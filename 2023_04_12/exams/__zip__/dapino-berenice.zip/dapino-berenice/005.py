def main(): 
    list = [2, 3, 6, 8, 1 ]
    num = 0
    for i in list: 
        num = num + i 
    
    print("Sum: ", num)

main()