def main(a):
    l = 0
    for _ in range(a):
        l= l+1
    return l

   
   
main()