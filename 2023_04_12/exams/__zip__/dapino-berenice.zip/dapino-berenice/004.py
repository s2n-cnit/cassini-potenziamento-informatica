def main(): 
    letter = str(input("Inserisci una stringa: "))
    list = ["a", "e", "i", "o", "u"]
 
    if letter in list: 
        print("La stringa è una vocale")
    else: 
        print("La stringa NON è una vocale")


main()
    
                