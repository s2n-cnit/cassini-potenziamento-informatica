def main(): 
    A = ["definizione", "cane", "dottore"]
    B = []
    
    for i in A: 
        B.append(len(i))
    
    print(B)

main()