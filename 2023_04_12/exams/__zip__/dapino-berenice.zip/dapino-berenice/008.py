def main(): 
    list = [10, 5, 7, 2]
    for i in list: 
    
        print("*"*i)

main()