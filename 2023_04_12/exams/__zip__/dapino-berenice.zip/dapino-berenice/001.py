def main(): 
    n1 = float(input("Inserisci il primo numero: "))
    n2 = float(input("inserisci il secondo numero: "))
    if n1 > n2: 
        print("Numero maggiore:", n1)
    elif n1 == n2:
        print(n1)
    else: 
        print("Numero maggiore:", n2)


main()
     