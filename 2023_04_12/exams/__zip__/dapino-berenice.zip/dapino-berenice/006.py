def main(): 
    list = [2, 9.8 ]
    molt = 1
    for i in list: 
        molt = molt * i 
    
    print("Moltiplicazione: ", molt)

main()