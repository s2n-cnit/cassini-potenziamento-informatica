lista_numeri = [2, 3, 4, 5]

prodotto = 1

for numero in lista_numeri:
    prodotto *= numero

print("Il prodotto di tutti gli elementi nella lista è:", prodotto)