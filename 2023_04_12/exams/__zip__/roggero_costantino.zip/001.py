firstnumber = float(input("Inserisci il primo numero: "))
secondnumber = float(input("Inserisci il secondo numero: "))

if firstnumber > secondnumber:
    print("Il numero più grande è:", firstnumber)
elif firstnumber < secondnumber:
    print("Il numero più grande è:", secondnumber)