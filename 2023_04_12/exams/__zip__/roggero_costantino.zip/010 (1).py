def parolen(parole: list):
    return [len(p) for p in parole]
