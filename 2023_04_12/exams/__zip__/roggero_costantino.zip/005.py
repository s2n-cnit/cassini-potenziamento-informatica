lista_numeri = [10, 20, 30, 40, 50]

somma = 0

for numero in lista_numeri:
    somma += numero

print("La somma di tutti gli elementi nella lista è:", somma)