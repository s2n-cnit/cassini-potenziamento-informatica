def length(a):
    l = 0
    for _ in a:
        l += 1
        
    return l