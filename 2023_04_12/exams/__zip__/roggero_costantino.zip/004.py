carattere = input("Inserisci un carattere: ")

if carattere in "aeiouAEIOU":
    print("Il carattere inserito è una vocale.")
else:
    print("Il carattere inserito non è una vocale.")