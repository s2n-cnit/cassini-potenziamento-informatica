def get_ascii(char: str):
    return ord(char)