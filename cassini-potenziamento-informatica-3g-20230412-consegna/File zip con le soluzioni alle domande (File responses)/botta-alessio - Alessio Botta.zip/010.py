def parolen(parole: list):
    return [len(p) for p in parole]

print(parolen(['gay', 'frocio', 'finocchio']))