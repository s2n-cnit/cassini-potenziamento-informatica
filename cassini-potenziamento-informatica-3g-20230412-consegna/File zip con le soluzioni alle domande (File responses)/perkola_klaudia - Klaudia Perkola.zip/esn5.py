#definisci la lista di numeri
lista_numeri = [10, 20, 30, 40, 50]

#inizializza una variabile per la somma
somma = 0

#utilizza un ciclo for per iterare su ciascun elemento della lista
for numero in lista_numeri:
    #aggiungi il numero corrente alla somma
    somma += numero

#stampa la somma a schermo
print("La somma di tutti gli elementi nella lista è:", somma)