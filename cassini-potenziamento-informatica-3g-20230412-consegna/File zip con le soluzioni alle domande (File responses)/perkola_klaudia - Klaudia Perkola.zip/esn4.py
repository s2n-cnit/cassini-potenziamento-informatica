carattere = input("Inserisci un carattere: ")
vocali = "aeiou"
if carattere in vocali:
    print(f"Il carattere {carattere} è una vocale")
else:
    print(f"Il carattere {carattere} non è una vocale")