def my_len(lst_or_str):
    length = 0
    for unit in lst_or_str:
        length += 1
    return length