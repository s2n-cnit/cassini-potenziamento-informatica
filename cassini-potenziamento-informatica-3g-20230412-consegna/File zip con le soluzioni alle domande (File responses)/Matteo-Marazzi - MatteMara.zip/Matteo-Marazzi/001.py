n1 = float(input("Inserisci il primo numero: "))
n2 = float(input("Inserisci il secondo numero: "))

if n1 > n2:
    print("Il numero più grande è:", n1)
elif n1 < n2:
    print("Il numero più grande è:", n2)
