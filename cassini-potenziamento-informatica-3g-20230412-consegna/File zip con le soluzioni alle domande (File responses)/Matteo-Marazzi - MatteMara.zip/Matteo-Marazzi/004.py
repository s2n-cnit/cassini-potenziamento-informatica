lettera = input("Inserisci un carattere: ")

if lettera in "aeiouAEIOU":
    print("Il carattere inserito è una vocale.")
else:
    print("Il carattere inserito non è una vocale.")