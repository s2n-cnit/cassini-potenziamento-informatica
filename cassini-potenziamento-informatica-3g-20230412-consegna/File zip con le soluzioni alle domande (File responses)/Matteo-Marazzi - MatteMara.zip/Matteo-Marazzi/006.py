lista_numeri = [1, 3, 5, 22]

prodotto = 1

for numero in lista_numeri:
    prodotto *= numero

print("Il prodotto di tutti gli elementi nella lista è:", prodotto)