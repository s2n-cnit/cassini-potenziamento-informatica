listanumeri = [15, 18, 22, 35, 44]

somma = 0

for numero in listanumeri:
    somma += numero

print("La somma di tutti gli elementi nella lista è:", somma)