# Definisci la lista di numeri
lista_numeri = [2, 3, 4, 5]

# Inizializza una variabile per il prodotto
prodotto = 1

# Utilizza un ciclo for per iterare su ciascun elemento della lista
for numero in lista_numeri:
    # Moltiplica il numero corrente al prodotto
    prodotto *= numero

# Stampa il prodotto a schermo
print("Il prodotto di tutti gli elementi nella lista è:", prodotto)