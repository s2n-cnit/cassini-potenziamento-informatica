carattere = input("Inserisci un carattere: ")

if carattere in "AEIOUaeiou":
    print("Il carattere inserito è una vocale.")
else:
    print(f"Il carattere inserito ({carattere}) non è una vocale.")
