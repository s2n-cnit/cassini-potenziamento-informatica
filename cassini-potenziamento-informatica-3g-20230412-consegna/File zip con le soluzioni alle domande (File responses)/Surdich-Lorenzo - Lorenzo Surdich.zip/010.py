def lunghezza_parole(lista):
    lunghezze = []
    for parola in lista:
        lunghezze.append(len(parola))
    return lunghezze