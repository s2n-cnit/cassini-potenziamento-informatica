def print():
    yay = True
    while yay:
        i = input()
        if i != '':
            print(i)
        else:
            yay = False
            
print()