Nlist = [1, 4, 6, 10]
for i in Nlist:
    element = int(i)
    ist = ''
    for i in range(element):
        ist = ist + '*'
    print(ist)
