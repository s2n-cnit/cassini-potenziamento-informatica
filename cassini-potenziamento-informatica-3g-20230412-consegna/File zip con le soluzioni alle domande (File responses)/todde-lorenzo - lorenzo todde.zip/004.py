def main():
    lett = str(input("Inserisci una lettera : "))
    if lett == 'a':
        print('vocale')
    elif lett == 'e':
        print('vocale')
    elif lett == 'i':
        print('vocale')
    elif lett == 'o':
        print('vocale')
    elif lett == 'u':
        print('vocale')
    elif lett == 'A':
        print('vocale')
    elif lett == 'E':
        print('vocale')
    elif lett == 'I':
        print('vocale')
    elif lett == 'O':
        print('vocale')
    elif lett == 'U':
        print('vocale')
    else: 
        print('Non Vocale')

main()

    


