def length(str):
    n = 0
    for i in str:
        n = n + 1
    print(n)
length('aaaaaa')