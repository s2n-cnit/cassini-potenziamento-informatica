import platform
    
def systemInfo():
    print(platform.system())
    print(platform.release())
    print(platform.version())

systemInfo()