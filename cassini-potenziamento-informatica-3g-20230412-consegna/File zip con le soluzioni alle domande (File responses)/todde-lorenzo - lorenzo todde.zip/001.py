def main(): 
    num1 = input("Inserisci il primo numero: ")
    num2 = input("Inserisci il secondo numero: ")
    if num1 >= num2:
        print(num1)
    else :
        print(num2)

main()
