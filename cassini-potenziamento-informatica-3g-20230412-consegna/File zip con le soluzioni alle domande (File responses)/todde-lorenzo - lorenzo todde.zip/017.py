def ascii(a):
    print(ord(a))
    return ord(a)

ascii('a')
ascii('A')
ascii('f')
ascii('9')
