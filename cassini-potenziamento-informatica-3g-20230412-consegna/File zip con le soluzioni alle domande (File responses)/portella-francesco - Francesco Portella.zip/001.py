def main():
    a = float(input('primo numero:'))
    b = float(input('secondo numero:'))
    if a >= b:
        print(a)
    else:
        print(b)

main()
