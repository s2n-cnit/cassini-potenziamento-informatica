def length(x):
    l = 0
    for _ in x:
        l += 1
        
    return l