def max_2():
    x = float(input('first number: '))
    y = float(input('second number: '))
    
    if x > y:
        print(x)
    else:
        print(y)
        
max_2()