def parolen(parole: list):
    return [len(x) for x in parole]
