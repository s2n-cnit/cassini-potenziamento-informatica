def istogramma(numbers):
    for n in numbers:
        print("*"*n)
