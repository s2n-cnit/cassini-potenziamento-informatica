def len(inlist):
    len = 0
    for _ in inlist:
        len += 1
    return len
