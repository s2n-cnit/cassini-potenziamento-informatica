def lenghezze(inlist):
    return [len(el) for el in inlist]
