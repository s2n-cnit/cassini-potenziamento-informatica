def ascii(c):
    return ord(c)
