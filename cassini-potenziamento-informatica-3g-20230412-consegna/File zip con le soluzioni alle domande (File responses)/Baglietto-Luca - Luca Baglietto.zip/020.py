def concatena():
    while True:
        s = input("Input: ")
        if s == '':
            break
        print(s, end=' ')
    print()
concatena()