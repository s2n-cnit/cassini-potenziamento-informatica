def converti(metri):
    print(f"{metri/1609.344:.5} Miglia terrestri")
    print(f"{metri/0.9144:.5} Iarde")
    print(f"{metri/0.3048:.5} Piedi")
    print(f"{metri/0.0254:.5} Pollici")
converti(100)