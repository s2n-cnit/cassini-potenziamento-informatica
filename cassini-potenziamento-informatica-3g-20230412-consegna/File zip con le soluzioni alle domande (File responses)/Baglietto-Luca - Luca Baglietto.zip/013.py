def secondi(gg, hh, min):
    return 60*(min+60*(hh+24*gg))
