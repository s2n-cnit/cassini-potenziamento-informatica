import platform

def os_info():
    return platform.platform()
