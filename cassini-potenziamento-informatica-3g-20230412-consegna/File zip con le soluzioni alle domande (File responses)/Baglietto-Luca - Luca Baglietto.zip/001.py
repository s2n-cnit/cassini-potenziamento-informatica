if __name__ == '__main__':
    a = int(input("Inserisci il primo numero: "))
    b = int(input("Inserisci il secondo numero: "))
    if a > b:
        mx = a
    else:
        mx = b
    print("Il massimo è", mx)
